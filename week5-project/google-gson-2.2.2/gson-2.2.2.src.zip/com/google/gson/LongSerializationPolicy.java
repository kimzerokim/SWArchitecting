/*    */ package com.google.gson;
/*    */ 
/*    */ public enum LongSerializationPolicy
/*    */ {
/* 34 */   DEFAULT, 
/*    */ 
/* 45 */   STRING;
/*    */ 
/*    */   public abstract JsonElement serialize(Long paramLong);
/*    */ }

/* Location:           /Users/soojin/Downloads/google-gson-2.2.2/gson-2.2.2.jar
 * Qualified Name:     com.google.gson.LongSerializationPolicy
 * JD-Core Version:    0.6.2
 */