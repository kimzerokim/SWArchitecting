package com.google.gson.internal;

public abstract interface ObjectConstructor<T>
{
  public abstract T construct();
}

/* Location:           /Users/soojin/Downloads/google-gson-2.2.2/gson-2.2.2.jar
 * Qualified Name:     com.google.gson.internal.ObjectConstructor
 * JD-Core Version:    0.6.2
 */