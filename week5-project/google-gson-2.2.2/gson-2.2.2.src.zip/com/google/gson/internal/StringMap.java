/*     */ package com.google.gson.internal;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ 
/*     */ public final class StringMap<V> extends AbstractMap<String, V>
/*     */ {
/*     */   private static final int MINIMUM_CAPACITY = 4;
/*     */   private static final int MAXIMUM_CAPACITY = 1073741824;
/*     */   private LinkedEntry<V> header;
/*  64 */   private static final Map.Entry[] EMPTY_TABLE = new LinkedEntry[2];
/*     */   private LinkedEntry<V>[] table;
/*     */   private int size;
/*     */   private int threshold;
/*     */   private Set<String> keySet;
/*     */   private Set<Map.Entry<String, V>> entrySet;
/*     */   private Collection<V> values;
/* 485 */   private static final int seed = new Random().nextInt();
/*     */ 
/*     */   public StringMap()
/*     */   {
/*  92 */     this.table = ((LinkedEntry[])EMPTY_TABLE);
/*  93 */     this.threshold = -1;
/*  94 */     this.header = new LinkedEntry();
/*     */   }
/*     */ 
/*     */   public int size() {
/*  98 */     return this.size;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key) {
/* 102 */     return ((key instanceof String)) && (getEntry((String)key) != null);
/*     */   }
/*     */ 
/*     */   public V get(Object key) {
/* 106 */     if ((key instanceof String)) {
/* 107 */       LinkedEntry entry = getEntry((String)key);
/* 108 */       return entry != null ? entry.value : null;
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   private LinkedEntry<V> getEntry(String key)
/*     */   {
/* 115 */     if (key == null) {
/* 116 */       return null;
/*     */     }
/*     */ 
/* 119 */     int hash = hash(key);
/* 120 */     LinkedEntry[] tab = this.table;
/* 121 */     for (LinkedEntry e = tab[(hash & tab.length - 1)]; e != null; e = e.next) {
/* 122 */       String eKey = e.key;
/* 123 */       if ((eKey == key) || ((e.hash == hash) && (key.equals(eKey)))) {
/* 124 */         return e;
/*     */       }
/*     */     }
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   public V put(String key, V value) {
/* 131 */     if (key == null) {
/* 132 */       throw new NullPointerException("key == null");
/*     */     }
/*     */ 
/* 135 */     int hash = hash(key);
/* 136 */     LinkedEntry[] tab = this.table;
/* 137 */     int index = hash & tab.length - 1;
/* 138 */     for (LinkedEntry e = tab[index]; e != null; e = e.next) {
/* 139 */       if ((e.hash == hash) && (key.equals(e.key))) {
/* 140 */         Object oldValue = e.value;
/* 141 */         e.value = value;
/* 142 */         return oldValue;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 147 */     if (this.size++ > this.threshold) {
/* 148 */       tab = doubleCapacity();
/* 149 */       index = hash & tab.length - 1;
/*     */     }
/* 151 */     addNewEntry(key, value, hash, index);
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */   private void addNewEntry(String key, V value, int hash, int index) {
/* 156 */     LinkedEntry header = this.header;
/*     */ 
/* 159 */     LinkedEntry oldTail = header.prv;
/* 160 */     LinkedEntry newTail = new LinkedEntry(key, value, hash, this.table[index], header, oldTail);
/*     */     LinkedEntry tmp52_49 = (header.prv = newTail); oldTail.nxt = tmp52_49; this.table[index] = tmp52_49;
/*     */   }
/*     */ 
/*     */   private LinkedEntry<V>[] makeTable(int newCapacity)
/*     */   {
/* 171 */     LinkedEntry[] newTable = (LinkedEntry[])new LinkedEntry[newCapacity];
/* 172 */     this.table = newTable;
/* 173 */     this.threshold = ((newCapacity >> 1) + (newCapacity >> 2));
/* 174 */     return newTable;
/*     */   }
/*     */ 
/*     */   private LinkedEntry<V>[] doubleCapacity()
/*     */   {
/* 184 */     LinkedEntry[] oldTable = this.table;
/* 185 */     int oldCapacity = oldTable.length;
/* 186 */     if (oldCapacity == 1073741824) {
/* 187 */       return oldTable;
/*     */     }
/* 189 */     int newCapacity = oldCapacity * 2;
/* 190 */     LinkedEntry[] newTable = makeTable(newCapacity);
/* 191 */     if (this.size == 0) {
/* 192 */       return newTable;
/*     */     }
/*     */ 
/* 195 */     for (int j = 0; j < oldCapacity; j++)
/*     */     {
/* 200 */       LinkedEntry e = oldTable[j];
/* 201 */       if (e != null)
/*     */       {
/* 204 */         int highBit = e.hash & oldCapacity;
/* 205 */         LinkedEntry broken = null;
/* 206 */         newTable[(j | highBit)] = e;
/* 207 */         for (LinkedEntry n = e.next; n != null; n = n.next) {
/* 208 */           int nextHighBit = n.hash & oldCapacity;
/* 209 */           if (nextHighBit != highBit) {
/* 210 */             if (broken == null)
/* 211 */               newTable[(j | nextHighBit)] = n;
/*     */             else {
/* 213 */               broken.next = n;
/*     */             }
/* 215 */             broken = e;
/* 216 */             highBit = nextHighBit;
/*     */           }
/* 207 */           e = n;
/*     */         }
/*     */ 
/* 219 */         if (broken != null)
/* 220 */           broken.next = null;
/*     */       }
/*     */     }
/* 223 */     return newTable;
/*     */   }
/*     */ 
/*     */   public V remove(Object key) {
/* 227 */     if ((key == null) || (!(key instanceof String))) {
/* 228 */       return null;
/*     */     }
/* 230 */     int hash = hash((String)key);
/* 231 */     LinkedEntry[] tab = this.table;
/* 232 */     int index = hash & tab.length - 1;
/* 233 */     LinkedEntry e = tab[index]; LinkedEntry prev = null;
/* 234 */     for (; e != null; e = e.next) {
/* 235 */       if ((e.hash == hash) && (key.equals(e.key))) {
/* 236 */         if (prev == null)
/* 237 */           tab[index] = e.next;
/*     */         else {
/* 239 */           prev.next = e.next;
/*     */         }
/* 241 */         this.size -= 1;
/* 242 */         unlink(e);
/* 243 */         return e.value;
/*     */       }
/* 234 */       prev = e;
/*     */     }
/*     */ 
/* 246 */     return null;
/*     */   }
/*     */ 
/*     */   private void unlink(LinkedEntry<V> e) {
/* 250 */     e.prv.nxt = e.nxt;
/* 251 */     e.nxt.prv = e.prv;
/* 252 */     e.nxt = (e.prv = null);
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 256 */     if (this.size != 0) {
/* 257 */       Arrays.fill(this.table, null);
/* 258 */       this.size = 0;
/*     */     }
/*     */ 
/* 262 */     LinkedEntry header = this.header;
/* 263 */     for (LinkedEntry e = header.nxt; e != header; ) {
/* 264 */       LinkedEntry nxt = e.nxt;
/* 265 */       e.nxt = (e.prv = null);
/* 266 */       e = nxt;
/*     */     }
/*     */ 
/* 269 */     header.nxt = (header.prv = header);
/*     */   }
/*     */ 
/*     */   public Set<String> keySet() {
/* 273 */     Set ks = this.keySet;
/* 274 */     return this.keySet = new KeySet(null);
/*     */   }
/*     */ 
/*     */   public Collection<V> values() {
/* 278 */     Collection vs = this.values;
/* 279 */     return this.values = new Values(null);
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<String, V>> entrySet() {
/* 283 */     Set es = this.entrySet;
/* 284 */     return this.entrySet = new EntrySet(null);
/*     */   }
/*     */ 
/*     */   private boolean removeMapping(Object key, Object value)
/*     */   {
/* 349 */     if ((key == null) || (!(key instanceof String))) {
/* 350 */       return false;
/*     */     }
/*     */ 
/* 353 */     int hash = hash((String)key);
/* 354 */     LinkedEntry[] tab = this.table;
/* 355 */     int index = hash & tab.length - 1;
/* 356 */     LinkedEntry e = tab[index]; for (LinkedEntry prev = null; e != null; e = e.next) {
/* 357 */       if ((e.hash == hash) && (key.equals(e.key))) {
/* 358 */         if (value == null ? e.value != null : !value.equals(e.value)) {
/* 359 */           return false;
/*     */         }
/* 361 */         if (prev == null)
/* 362 */           tab[index] = e.next;
/*     */         else {
/* 364 */           prev.next = e.next;
/*     */         }
/* 366 */         this.size -= 1;
/* 367 */         unlink(e);
/* 368 */         return true;
/*     */       }
/* 356 */       prev = e;
/*     */     }
/*     */ 
/* 371 */     return false;
/*     */   }
/*     */ 
/*     */   private static int hash(String key)
/*     */   {
/* 498 */     int h = seed;
/* 499 */     for (int i = 0; i < key.length(); i++) {
/* 500 */       int h2 = h + key.charAt(i);
/* 501 */       int h3 = h2 + h2 << 10;
/* 502 */       h = h3 ^ h3 >>> 6;
/*     */     }
/*     */ 
/* 509 */     h ^= h >>> 20 ^ h >>> 12;
/* 510 */     return h ^ h >>> 7 ^ h >>> 4;
/*     */   }
/*     */ 
/*     */   private final class EntrySet extends AbstractSet<Map.Entry<String, V>>
/*     */   {
/*     */     private EntrySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<Map.Entry<String, V>> iterator()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: new 4	com/google/gson/internal/StringMap$EntrySet$1
/*     */       //   3: dup
/*     */       //   4: aload_0
/*     */       //   5: invokespecial 5	com/google/gson/internal/StringMap$EntrySet$1:<init>	(Lcom/google/gson/internal/StringMap$EntrySet;)V
/*     */       //   8: areturn
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o)
/*     */     {
/* 460 */       if (!(o instanceof Map.Entry)) {
/* 461 */         return false;
/*     */       }
/* 463 */       Map.Entry e = (Map.Entry)o;
/* 464 */       Object mappedValue = StringMap.this.get(e.getKey());
/* 465 */       return (mappedValue != null) && (mappedValue.equals(e.getValue()));
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o) {
/* 469 */       if (!(o instanceof Map.Entry)) {
/* 470 */         return false;
/*     */       }
/* 472 */       Map.Entry e = (Map.Entry)o;
/* 473 */       return StringMap.this.removeMapping(e.getKey(), e.getValue());
/*     */     }
/*     */ 
/*     */     public int size() {
/* 477 */       return StringMap.this.size;
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 481 */       StringMap.this.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class Values extends AbstractCollection<V>
/*     */   {
/*     */     private Values()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<V> iterator()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: new 4	com/google/gson/internal/StringMap$Values$1
/*     */       //   3: dup
/*     */       //   4: aload_0
/*     */       //   5: invokespecial 5	com/google/gson/internal/StringMap$Values$1:<init>	(Lcom/google/gson/internal/StringMap$Values;)V
/*     */       //   8: areturn
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 438 */       return StringMap.this.size;
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o) {
/* 442 */       return StringMap.this.containsValue(o);
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 446 */       StringMap.this.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class KeySet extends AbstractSet<String>
/*     */   {
/*     */     private KeySet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Iterator<String> iterator()
/*     */     {
/*     */       // Byte code:
/*     */       //   0: new 4	com/google/gson/internal/StringMap$KeySet$1
/*     */       //   3: dup
/*     */       //   4: aload_0
/*     */       //   5: invokespecial 5	com/google/gson/internal/StringMap$KeySet$1:<init>	(Lcom/google/gson/internal/StringMap$KeySet;)V
/*     */       //   8: areturn
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 410 */       return StringMap.this.size;
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o) {
/* 414 */       return StringMap.this.containsKey(o);
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o) {
/* 418 */       int oldSize = StringMap.this.size;
/* 419 */       StringMap.this.remove(o);
/* 420 */       return StringMap.this.size != oldSize;
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 424 */       StringMap.this.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private abstract class LinkedHashIterator<T>
/*     */     implements Iterator<T>
/*     */   {
/* 375 */     StringMap.LinkedEntry<V> next = StringMap.this.header.nxt;
/* 376 */     StringMap.LinkedEntry<V> lastReturned = null;
/*     */ 
/*     */     private LinkedHashIterator() {  } 
/* 379 */     public final boolean hasNext() { return this.next != StringMap.this.header; }
/*     */ 
/*     */     final StringMap.LinkedEntry<V> nextEntry()
/*     */     {
/* 383 */       StringMap.LinkedEntry e = this.next;
/* 384 */       if (e == StringMap.this.header) {
/* 385 */         throw new NoSuchElementException();
/*     */       }
/* 387 */       this.next = e.nxt;
/* 388 */       return this.lastReturned = e;
/*     */     }
/*     */ 
/*     */     public final void remove() {
/* 392 */       if (this.lastReturned == null) {
/* 393 */         throw new IllegalStateException();
/*     */       }
/* 395 */       StringMap.this.remove(this.lastReturned.key);
/* 396 */       this.lastReturned = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class LinkedEntry<V>
/*     */     implements Map.Entry<String, V>
/*     */   {
/*     */     final String key;
/*     */     V value;
/*     */     final int hash;
/*     */     LinkedEntry<V> next;
/*     */     LinkedEntry<V> nxt;
/*     */     LinkedEntry<V> prv;
/*     */ 
/*     */     LinkedEntry()
/*     */     {
/* 297 */       this(null, null, 0, null, null, null);
/* 298 */       this.prv = this; this.nxt = this;
/*     */     }
/*     */ 
/*     */     LinkedEntry(String key, V value, int hash, LinkedEntry<V> next, LinkedEntry<V> nxt, LinkedEntry<V> prv)
/*     */     {
/* 303 */       this.key = key;
/* 304 */       this.value = value;
/* 305 */       this.hash = hash;
/* 306 */       this.next = next;
/* 307 */       this.nxt = nxt;
/* 308 */       this.prv = prv;
/*     */     }
/*     */ 
/*     */     public final String getKey() {
/* 312 */       return this.key;
/*     */     }
/*     */ 
/*     */     public final V getValue() {
/* 316 */       return this.value;
/*     */     }
/*     */ 
/*     */     public final V setValue(V value) {
/* 320 */       Object oldValue = this.value;
/* 321 */       this.value = value;
/* 322 */       return oldValue;
/*     */     }
/*     */ 
/*     */     public final boolean equals(Object o) {
/* 326 */       if (!(o instanceof Map.Entry)) {
/* 327 */         return false;
/*     */       }
/* 329 */       Map.Entry e = (Map.Entry)o;
/* 330 */       Object eValue = e.getValue();
/* 331 */       return (this.key.equals(e.getKey())) && (this.value == null ? eValue == null : this.value.equals(eValue));
/*     */     }
/*     */ 
/*     */     public final int hashCode()
/*     */     {
/* 336 */       return (this.key == null ? 0 : this.key.hashCode()) ^ (this.value == null ? 0 : this.value.hashCode());
/*     */     }
/*     */ 
/*     */     public final String toString() {
/* 340 */       return this.key + "=" + this.value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/soojin/Downloads/google-gson-2.2.2/gson-2.2.2.jar
 * Qualified Name:     com.google.gson.internal.StringMap
 * JD-Core Version:    0.6.2
 */