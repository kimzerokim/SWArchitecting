/*     */ package com.google.gson.stream;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.Flushable;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class JsonWriter
/*     */   implements Closeable, Flushable
/*     */ {
/* 139 */   private static final String[] REPLACEMENT_CHARS = new String[''];
/*     */   private static final String[] HTML_SAFE_REPLACEMENT_CHARS;
/*     */   private final Writer out;
/* 161 */   private final List<JsonScope> stack = new ArrayList();
/*     */   private String indent;
/*     */   private String separator;
/*     */   private boolean lenient;
/*     */   private boolean htmlSafe;
/*     */   private String deferredName;
/*     */   private boolean serializeNulls;
/*     */ 
/*     */   public JsonWriter(Writer out)
/*     */   {
/* 163 */     this.stack.add(JsonScope.EMPTY_DOCUMENT);
/*     */ 
/* 175 */     this.separator = ":";
/*     */ 
/* 183 */     this.serializeNulls = true;
/*     */ 
/* 191 */     if (out == null) {
/* 192 */       throw new NullPointerException("out == null");
/*     */     }
/* 194 */     this.out = out;
/*     */   }
/*     */ 
/*     */   public final void setIndent(String indent)
/*     */   {
/* 206 */     if (indent.length() == 0) {
/* 207 */       this.indent = null;
/* 208 */       this.separator = ":";
/*     */     } else {
/* 210 */       this.indent = indent;
/* 211 */       this.separator = ": ";
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void setLenient(boolean lenient)
/*     */   {
/* 228 */     this.lenient = lenient;
/*     */   }
/*     */ 
/*     */   public boolean isLenient()
/*     */   {
/* 235 */     return this.lenient;
/*     */   }
/*     */ 
/*     */   public final void setHtmlSafe(boolean htmlSafe)
/*     */   {
/* 246 */     this.htmlSafe = htmlSafe;
/*     */   }
/*     */ 
/*     */   public final boolean isHtmlSafe()
/*     */   {
/* 254 */     return this.htmlSafe;
/*     */   }
/*     */ 
/*     */   public final void setSerializeNulls(boolean serializeNulls)
/*     */   {
/* 262 */     this.serializeNulls = serializeNulls;
/*     */   }
/*     */ 
/*     */   public final boolean getSerializeNulls()
/*     */   {
/* 270 */     return this.serializeNulls;
/*     */   }
/*     */ 
/*     */   public JsonWriter beginArray()
/*     */     throws IOException
/*     */   {
/* 280 */     writeDeferredName();
/* 281 */     return open(JsonScope.EMPTY_ARRAY, "[");
/*     */   }
/*     */ 
/*     */   public JsonWriter endArray()
/*     */     throws IOException
/*     */   {
/* 290 */     return close(JsonScope.EMPTY_ARRAY, JsonScope.NONEMPTY_ARRAY, "]");
/*     */   }
/*     */ 
/*     */   public JsonWriter beginObject()
/*     */     throws IOException
/*     */   {
/* 300 */     writeDeferredName();
/* 301 */     return open(JsonScope.EMPTY_OBJECT, "{");
/*     */   }
/*     */ 
/*     */   public JsonWriter endObject()
/*     */     throws IOException
/*     */   {
/* 310 */     return close(JsonScope.EMPTY_OBJECT, JsonScope.NONEMPTY_OBJECT, "}");
/*     */   }
/*     */ 
/*     */   private JsonWriter open(JsonScope empty, String openBracket)
/*     */     throws IOException
/*     */   {
/* 318 */     beforeValue(true);
/* 319 */     this.stack.add(empty);
/* 320 */     this.out.write(openBracket);
/* 321 */     return this;
/*     */   }
/*     */ 
/*     */   private JsonWriter close(JsonScope empty, JsonScope nonempty, String closeBracket)
/*     */     throws IOException
/*     */   {
/* 330 */     JsonScope context = peek();
/* 331 */     if ((context != nonempty) && (context != empty)) {
/* 332 */       throw new IllegalStateException("Nesting problem: " + this.stack);
/*     */     }
/* 334 */     if (this.deferredName != null) {
/* 335 */       throw new IllegalStateException("Dangling name: " + this.deferredName);
/*     */     }
/*     */ 
/* 338 */     this.stack.remove(this.stack.size() - 1);
/* 339 */     if (context == nonempty) {
/* 340 */       newline();
/*     */     }
/* 342 */     this.out.write(closeBracket);
/* 343 */     return this;
/*     */   }
/*     */ 
/*     */   private JsonScope peek()
/*     */   {
/* 350 */     int size = this.stack.size();
/* 351 */     if (size == 0) {
/* 352 */       throw new IllegalStateException("JsonWriter is closed.");
/*     */     }
/* 354 */     return (JsonScope)this.stack.get(size - 1);
/*     */   }
/*     */ 
/*     */   private void replaceTop(JsonScope topOfStack)
/*     */   {
/* 361 */     this.stack.set(this.stack.size() - 1, topOfStack);
/*     */   }
/*     */ 
/*     */   public JsonWriter name(String name)
/*     */     throws IOException
/*     */   {
/* 371 */     if (name == null) {
/* 372 */       throw new NullPointerException("name == null");
/*     */     }
/* 374 */     if (this.deferredName != null) {
/* 375 */       throw new IllegalStateException();
/*     */     }
/* 377 */     if (this.stack.isEmpty()) {
/* 378 */       throw new IllegalStateException("JsonWriter is closed.");
/*     */     }
/* 380 */     this.deferredName = name;
/* 381 */     return this;
/*     */   }
/*     */ 
/*     */   private void writeDeferredName() throws IOException {
/* 385 */     if (this.deferredName != null) {
/* 386 */       beforeName();
/* 387 */       string(this.deferredName);
/* 388 */       this.deferredName = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public JsonWriter value(String value)
/*     */     throws IOException
/*     */   {
/* 399 */     if (value == null) {
/* 400 */       return nullValue();
/*     */     }
/* 402 */     writeDeferredName();
/* 403 */     beforeValue(false);
/* 404 */     string(value);
/* 405 */     return this;
/*     */   }
/*     */ 
/*     */   public JsonWriter nullValue()
/*     */     throws IOException
/*     */   {
/* 414 */     if (this.deferredName != null) {
/* 415 */       if (this.serializeNulls) {
/* 416 */         writeDeferredName();
/*     */       } else {
/* 418 */         this.deferredName = null;
/* 419 */         return this;
/*     */       }
/*     */     }
/* 422 */     beforeValue(false);
/* 423 */     this.out.write("null");
/* 424 */     return this;
/*     */   }
/*     */ 
/*     */   public JsonWriter value(boolean value)
/*     */     throws IOException
/*     */   {
/* 433 */     writeDeferredName();
/* 434 */     beforeValue(false);
/* 435 */     this.out.write(value ? "true" : "false");
/* 436 */     return this;
/*     */   }
/*     */ 
/*     */   public JsonWriter value(double value)
/*     */     throws IOException
/*     */   {
/* 447 */     if ((Double.isNaN(value)) || (Double.isInfinite(value))) {
/* 448 */       throw new IllegalArgumentException("Numeric values must be finite, but was " + value);
/*     */     }
/* 450 */     writeDeferredName();
/* 451 */     beforeValue(false);
/* 452 */     this.out.append(Double.toString(value));
/* 453 */     return this;
/*     */   }
/*     */ 
/*     */   public JsonWriter value(long value)
/*     */     throws IOException
/*     */   {
/* 462 */     writeDeferredName();
/* 463 */     beforeValue(false);
/* 464 */     this.out.write(Long.toString(value));
/* 465 */     return this;
/*     */   }
/*     */ 
/*     */   public JsonWriter value(Number value)
/*     */     throws IOException
/*     */   {
/* 476 */     if (value == null) {
/* 477 */       return nullValue();
/*     */     }
/*     */ 
/* 480 */     writeDeferredName();
/* 481 */     String string = value.toString();
/* 482 */     if ((!this.lenient) && ((string.equals("-Infinity")) || (string.equals("Infinity")) || (string.equals("NaN"))))
/*     */     {
/* 484 */       throw new IllegalArgumentException("Numeric values must be finite, but was " + value);
/*     */     }
/* 486 */     beforeValue(false);
/* 487 */     this.out.append(string);
/* 488 */     return this;
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 496 */     if (this.stack.isEmpty()) {
/* 497 */       throw new IllegalStateException("JsonWriter is closed.");
/*     */     }
/* 499 */     this.out.flush();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 508 */     this.out.close();
/*     */ 
/* 510 */     int size = this.stack.size();
/* 511 */     if ((size > 1) || ((size == 1) && (this.stack.get(size - 1) != JsonScope.NONEMPTY_DOCUMENT))) {
/* 512 */       throw new IOException("Incomplete document");
/*     */     }
/* 514 */     this.stack.clear();
/*     */   }
/*     */ 
/*     */   private void string(String value) throws IOException {
/* 518 */     String[] replacements = this.htmlSafe ? HTML_SAFE_REPLACEMENT_CHARS : REPLACEMENT_CHARS;
/* 519 */     this.out.write("\"");
/* 520 */     int last = 0;
/* 521 */     int length = value.length();
/* 522 */     for (int i = 0; i < length; i++) {
/* 523 */       char c = value.charAt(i);
/*     */       String replacement;
/* 525 */       if (c < '') {
/* 526 */         String replacement = replacements[c];
/* 527 */         if (replacement == null)
/* 528 */           continue;
/*     */       }
/*     */       else
/*     */       {
/*     */         String replacement;
/* 530 */         if (c == ' ') {
/* 531 */           replacement = "\\u2028"; } else {
/* 532 */           if (c != ' ') continue;
/* 533 */           replacement = "\\u2029";
/*     */         }
/*     */       }
/*     */ 
/* 537 */       if (last < i) {
/* 538 */         this.out.write(value, last, i - last);
/*     */       }
/* 540 */       this.out.write(replacement);
/* 541 */       last = i + 1;
/*     */     }
/* 543 */     if (last < length) {
/* 544 */       this.out.write(value, last, length - last);
/*     */     }
/* 546 */     this.out.write("\"");
/*     */   }
/*     */ 
/*     */   private void newline() throws IOException {
/* 550 */     if (this.indent == null) {
/* 551 */       return;
/*     */     }
/*     */ 
/* 554 */     this.out.write("\n");
/* 555 */     for (int i = 1; i < this.stack.size(); i++)
/* 556 */       this.out.write(this.indent);
/*     */   }
/*     */ 
/*     */   private void beforeName()
/*     */     throws IOException
/*     */   {
/* 565 */     JsonScope context = peek();
/* 566 */     if (context == JsonScope.NONEMPTY_OBJECT)
/* 567 */       this.out.write(44);
/* 568 */     else if (context != JsonScope.EMPTY_OBJECT) {
/* 569 */       throw new IllegalStateException("Nesting problem: " + this.stack);
/*     */     }
/* 571 */     newline();
/* 572 */     replaceTop(JsonScope.DANGLING_NAME);
/*     */   }
/*     */ 
/*     */   private void beforeValue(boolean root)
/*     */     throws IOException
/*     */   {
/* 585 */     switch (1.$SwitchMap$com$google$gson$stream$JsonScope[peek().ordinal()]) {
/*     */     case 1:
/* 587 */       if (!this.lenient) {
/* 588 */         throw new IllegalStateException("JSON must have only one top-level value.");
/*     */       }
/*     */ 
/*     */     case 2:
/* 593 */       if ((!this.lenient) && (!root)) {
/* 594 */         throw new IllegalStateException("JSON must start with an array or an object.");
/*     */       }
/*     */ 
/* 597 */       replaceTop(JsonScope.NONEMPTY_DOCUMENT);
/* 598 */       break;
/*     */     case 3:
/* 601 */       replaceTop(JsonScope.NONEMPTY_ARRAY);
/* 602 */       newline();
/* 603 */       break;
/*     */     case 4:
/* 606 */       this.out.append(',');
/* 607 */       newline();
/* 608 */       break;
/*     */     case 5:
/* 611 */       this.out.append(this.separator);
/* 612 */       replaceTop(JsonScope.NONEMPTY_OBJECT);
/* 613 */       break;
/*     */     }
/*     */ 
/* 616 */     throw new IllegalStateException("Nesting problem: " + this.stack);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 140 */     for (int i = 0; i <= 31; i++) {
/* 141 */       REPLACEMENT_CHARS[i] = String.format("\\u%04x", new Object[] { Integer.valueOf(i) });
/*     */     }
/* 143 */     REPLACEMENT_CHARS[34] = "\\\"";
/* 144 */     REPLACEMENT_CHARS[92] = "\\\\";
/* 145 */     REPLACEMENT_CHARS[9] = "\\t";
/* 146 */     REPLACEMENT_CHARS[8] = "\\b";
/* 147 */     REPLACEMENT_CHARS[10] = "\\n";
/* 148 */     REPLACEMENT_CHARS[13] = "\\r";
/* 149 */     REPLACEMENT_CHARS[12] = "\\f";
/* 150 */     HTML_SAFE_REPLACEMENT_CHARS = (String[])REPLACEMENT_CHARS.clone();
/* 151 */     HTML_SAFE_REPLACEMENT_CHARS[60] = "\\u003c";
/* 152 */     HTML_SAFE_REPLACEMENT_CHARS[62] = "\\u003e";
/* 153 */     HTML_SAFE_REPLACEMENT_CHARS[38] = "\\u0026";
/* 154 */     HTML_SAFE_REPLACEMENT_CHARS[61] = "\\u003d";
/* 155 */     HTML_SAFE_REPLACEMENT_CHARS[39] = "\\u0027";
/*     */   }
/*     */ }

/* Location:           /Users/soojin/Downloads/google-gson-2.2.2/gson-2.2.2.jar
 * Qualified Name:     com.google.gson.stream.JsonWriter
 * JD-Core Version:    0.6.2
 */