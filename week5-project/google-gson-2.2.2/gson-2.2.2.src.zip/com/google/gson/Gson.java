/*     */ package com.google.gson;
/*     */ 
/*     */ import com.google.gson.internal.ConstructorConstructor;
/*     */ import com.google.gson.internal.Excluder;
/*     */ import com.google.gson.internal.Primitives;
/*     */ import com.google.gson.internal.Streams;
/*     */ import com.google.gson.internal.bind.ArrayTypeAdapter;
/*     */ import com.google.gson.internal.bind.CollectionTypeAdapterFactory;
/*     */ import com.google.gson.internal.bind.DateTypeAdapter;
/*     */ import com.google.gson.internal.bind.JsonTreeReader;
/*     */ import com.google.gson.internal.bind.JsonTreeWriter;
/*     */ import com.google.gson.internal.bind.MapTypeAdapterFactory;
/*     */ import com.google.gson.internal.bind.ObjectTypeAdapter;
/*     */ import com.google.gson.internal.bind.ReflectiveTypeAdapterFactory;
/*     */ import com.google.gson.internal.bind.SqlDateTypeAdapter;
/*     */ import com.google.gson.internal.bind.TimeTypeAdapter;
/*     */ import com.google.gson.internal.bind.TypeAdapters;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import com.google.gson.stream.JsonToken;
/*     */ import com.google.gson.stream.JsonWriter;
/*     */ import com.google.gson.stream.MalformedJsonException;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Type;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public final class Gson
/*     */ {
/*     */   static final boolean DEFAULT_JSON_NON_EXECUTABLE = false;
/*     */   private static final String JSON_NON_EXECUTABLE_PREFIX = ")]}'\n";
/* 110 */   private final ThreadLocal<Map<TypeToken<?>, FutureTypeAdapter<?>>> calls = new ThreadLocal()
/*     */   {
/*     */     protected Map<TypeToken<?>, Gson.FutureTypeAdapter<?>> initialValue() {
/* 113 */       return new HashMap();
/*     */     }
/* 110 */   };
/*     */ 
/* 117 */   private final Map<TypeToken<?>, TypeAdapter<?>> typeTokenCache = Collections.synchronizedMap(new HashMap());
/*     */   private final List<TypeAdapterFactory> factories;
/*     */   private final ConstructorConstructor constructorConstructor;
/*     */   private final boolean serializeNulls;
/*     */   private final boolean htmlSafe;
/*     */   private final boolean generateNonExecutableJson;
/*     */   private final boolean prettyPrinting;
/* 128 */   final JsonDeserializationContext deserializationContext = new JsonDeserializationContext()
/*     */   {
/*     */     public <T> T deserialize(JsonElement json, Type typeOfT) throws JsonParseException {
/* 131 */       return Gson.this.fromJson(json, typeOfT);
/*     */     }
/* 128 */   };
/*     */ 
/* 135 */   final JsonSerializationContext serializationContext = new JsonSerializationContext() {
/*     */     public JsonElement serialize(Object src) {
/* 137 */       return Gson.this.toJsonTree(src);
/*     */     }
/*     */     public JsonElement serialize(Object src, Type typeOfSrc) {
/* 140 */       return Gson.this.toJsonTree(src, typeOfSrc);
/*     */     }
/* 135 */   };
/*     */ 
/*     */   public Gson()
/*     */   {
/* 179 */     this(Excluder.DEFAULT, FieldNamingPolicy.IDENTITY, Collections.emptyMap(), false, false, false, true, false, false, LongSerializationPolicy.DEFAULT, Collections.emptyList());
/*     */   }
/*     */ 
/*     */   Gson(Excluder excluder, FieldNamingStrategy fieldNamingPolicy, Map<Type, InstanceCreator<?>> instanceCreators, boolean serializeNulls, boolean complexMapKeySerialization, boolean generateNonExecutableGson, boolean htmlSafe, boolean prettyPrinting, boolean serializeSpecialFloatingPointValues, LongSerializationPolicy longSerializationPolicy, List<TypeAdapterFactory> typeAdapterFactories)
/*     */   {
/* 191 */     this.constructorConstructor = new ConstructorConstructor(instanceCreators);
/* 192 */     this.serializeNulls = serializeNulls;
/* 193 */     this.generateNonExecutableJson = generateNonExecutableGson;
/* 194 */     this.htmlSafe = htmlSafe;
/* 195 */     this.prettyPrinting = prettyPrinting;
/*     */ 
/* 197 */     List factories = new ArrayList();
/*     */ 
/* 200 */     factories.add(TypeAdapters.JSON_ELEMENT_FACTORY);
/* 201 */     factories.add(ObjectTypeAdapter.FACTORY);
/*     */ 
/* 204 */     factories.addAll(typeAdapterFactories);
/*     */ 
/* 207 */     factories.add(TypeAdapters.STRING_FACTORY);
/* 208 */     factories.add(TypeAdapters.INTEGER_FACTORY);
/* 209 */     factories.add(TypeAdapters.BOOLEAN_FACTORY);
/* 210 */     factories.add(TypeAdapters.BYTE_FACTORY);
/* 211 */     factories.add(TypeAdapters.SHORT_FACTORY);
/* 212 */     factories.add(TypeAdapters.newFactory(Long.TYPE, Long.class, longAdapter(longSerializationPolicy)));
/*     */ 
/* 214 */     factories.add(TypeAdapters.newFactory(Double.TYPE, Double.class, doubleAdapter(serializeSpecialFloatingPointValues)));
/*     */ 
/* 216 */     factories.add(TypeAdapters.newFactory(Float.TYPE, Float.class, floatAdapter(serializeSpecialFloatingPointValues)));
/*     */ 
/* 218 */     factories.add(TypeAdapters.NUMBER_FACTORY);
/* 219 */     factories.add(TypeAdapters.CHARACTER_FACTORY);
/* 220 */     factories.add(TypeAdapters.STRING_BUILDER_FACTORY);
/* 221 */     factories.add(TypeAdapters.STRING_BUFFER_FACTORY);
/* 222 */     factories.add(TypeAdapters.newFactory(BigDecimal.class, TypeAdapters.BIG_DECIMAL));
/* 223 */     factories.add(TypeAdapters.newFactory(BigInteger.class, TypeAdapters.BIG_INTEGER));
/* 224 */     factories.add(TypeAdapters.URL_FACTORY);
/* 225 */     factories.add(TypeAdapters.URI_FACTORY);
/* 226 */     factories.add(TypeAdapters.UUID_FACTORY);
/* 227 */     factories.add(TypeAdapters.LOCALE_FACTORY);
/* 228 */     factories.add(TypeAdapters.INET_ADDRESS_FACTORY);
/* 229 */     factories.add(TypeAdapters.BIT_SET_FACTORY);
/* 230 */     factories.add(DateTypeAdapter.FACTORY);
/* 231 */     factories.add(TypeAdapters.CALENDAR_FACTORY);
/* 232 */     factories.add(TimeTypeAdapter.FACTORY);
/* 233 */     factories.add(SqlDateTypeAdapter.FACTORY);
/* 234 */     factories.add(TypeAdapters.TIMESTAMP_FACTORY);
/* 235 */     factories.add(ArrayTypeAdapter.FACTORY);
/* 236 */     factories.add(TypeAdapters.ENUM_FACTORY);
/* 237 */     factories.add(TypeAdapters.CLASS_FACTORY);
/*     */ 
/* 240 */     factories.add(excluder);
/*     */ 
/* 243 */     factories.add(new CollectionTypeAdapterFactory(this.constructorConstructor));
/* 244 */     factories.add(new MapTypeAdapterFactory(this.constructorConstructor, complexMapKeySerialization));
/* 245 */     factories.add(new ReflectiveTypeAdapterFactory(this.constructorConstructor, fieldNamingPolicy, excluder));
/*     */ 
/* 248 */     this.factories = Collections.unmodifiableList(factories);
/*     */   }
/*     */ 
/*     */   private TypeAdapter<Number> doubleAdapter(boolean serializeSpecialFloatingPointValues) {
/* 252 */     if (serializeSpecialFloatingPointValues) {
/* 253 */       return TypeAdapters.DOUBLE;
/*     */     }
/* 255 */     return new TypeAdapter() {
/*     */       public Double read(JsonReader in) throws IOException {
/* 257 */         if (in.peek() == JsonToken.NULL) {
/* 258 */           in.nextNull();
/* 259 */           return null;
/*     */         }
/* 261 */         return Double.valueOf(in.nextDouble());
/*     */       }
/*     */       public void write(JsonWriter out, Number value) throws IOException {
/* 264 */         if (value == null) {
/* 265 */           out.nullValue();
/* 266 */           return;
/*     */         }
/* 268 */         double doubleValue = value.doubleValue();
/* 269 */         Gson.this.checkValidFloatingPoint(doubleValue);
/* 270 */         out.value(value);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private TypeAdapter<Number> floatAdapter(boolean serializeSpecialFloatingPointValues) {
/* 276 */     if (serializeSpecialFloatingPointValues) {
/* 277 */       return TypeAdapters.FLOAT;
/*     */     }
/* 279 */     return new TypeAdapter() {
/*     */       public Float read(JsonReader in) throws IOException {
/* 281 */         if (in.peek() == JsonToken.NULL) {
/* 282 */           in.nextNull();
/* 283 */           return null;
/*     */         }
/* 285 */         return Float.valueOf((float)in.nextDouble());
/*     */       }
/*     */       public void write(JsonWriter out, Number value) throws IOException {
/* 288 */         if (value == null) {
/* 289 */           out.nullValue();
/* 290 */           return;
/*     */         }
/* 292 */         float floatValue = value.floatValue();
/* 293 */         Gson.this.checkValidFloatingPoint(floatValue);
/* 294 */         out.value(value);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private void checkValidFloatingPoint(double value) {
/* 300 */     if ((Double.isNaN(value)) || (Double.isInfinite(value)))
/* 301 */       throw new IllegalArgumentException(value + " is not a valid double value as per JSON specification. To override this" + " behavior, use GsonBuilder.serializeSpecialDoubleValues() method.");
/*     */   }
/*     */ 
/*     */   private TypeAdapter<Number> longAdapter(LongSerializationPolicy longSerializationPolicy)
/*     */   {
/* 308 */     if (longSerializationPolicy == LongSerializationPolicy.DEFAULT) {
/* 309 */       return TypeAdapters.LONG;
/*     */     }
/* 311 */     return new TypeAdapter() {
/*     */       public Number read(JsonReader in) throws IOException {
/* 313 */         if (in.peek() == JsonToken.NULL) {
/* 314 */           in.nextNull();
/* 315 */           return null;
/*     */         }
/* 317 */         return Long.valueOf(in.nextLong());
/*     */       }
/*     */       public void write(JsonWriter out, Number value) throws IOException {
/* 320 */         if (value == null) {
/* 321 */           out.nullValue();
/* 322 */           return;
/*     */         }
/* 324 */         out.value(value.toString());
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public <T> TypeAdapter<T> getAdapter(TypeToken<T> type)
/*     */   {
/* 337 */     TypeAdapter cached = (TypeAdapter)this.typeTokenCache.get(type);
/* 338 */     if (cached != null) {
/* 339 */       return cached;
/*     */     }
/*     */ 
/* 342 */     Map threadCalls = (Map)this.calls.get();
/*     */ 
/* 344 */     FutureTypeAdapter ongoingCall = (FutureTypeAdapter)threadCalls.get(type);
/* 345 */     if (ongoingCall != null) {
/* 346 */       return ongoingCall;
/*     */     }
/*     */ 
/* 349 */     FutureTypeAdapter call = new FutureTypeAdapter();
/* 350 */     threadCalls.put(type, call);
/*     */     try {
/* 352 */       for (TypeAdapterFactory factory : this.factories) {
/* 353 */         TypeAdapter candidate = factory.create(this, type);
/* 354 */         if (candidate != null) {
/* 355 */           call.setDelegate(candidate);
/* 356 */           this.typeTokenCache.put(type, candidate);
/* 357 */           return candidate;
/*     */         }
/*     */       }
/* 360 */       throw new IllegalArgumentException("GSON cannot handle " + type);
/*     */     } finally {
/* 362 */       threadCalls.remove(type);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> TypeAdapter<T> getDelegateAdapter(TypeAdapterFactory skipPast, TypeToken<T> type)
/*     */   {
/* 413 */     boolean skipPastFound = false;
/*     */ 
/* 415 */     for (TypeAdapterFactory factory : this.factories) {
/* 416 */       if (!skipPastFound) {
/* 417 */         if (factory == skipPast) {
/* 418 */           skipPastFound = true;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 423 */         TypeAdapter candidate = factory.create(this, type);
/* 424 */         if (candidate != null)
/* 425 */           return candidate;
/*     */       }
/*     */     }
/* 428 */     throw new IllegalArgumentException("GSON cannot serialize " + type);
/*     */   }
/*     */ 
/*     */   public <T> TypeAdapter<T> getAdapter(Class<T> type)
/*     */   {
/* 438 */     return getAdapter(TypeToken.get(type));
/*     */   }
/*     */ 
/*     */   public JsonElement toJsonTree(Object src)
/*     */   {
/* 455 */     if (src == null) {
/* 456 */       return JsonNull.INSTANCE;
/*     */     }
/* 458 */     return toJsonTree(src, src.getClass());
/*     */   }
/*     */ 
/*     */   public JsonElement toJsonTree(Object src, Type typeOfSrc)
/*     */   {
/* 478 */     JsonTreeWriter writer = new JsonTreeWriter();
/* 479 */     toJson(src, typeOfSrc, writer);
/* 480 */     return writer.get();
/*     */   }
/*     */ 
/*     */   public String toJson(Object src)
/*     */   {
/* 497 */     if (src == null) {
/* 498 */       return toJson(JsonNull.INSTANCE);
/*     */     }
/* 500 */     return toJson(src, src.getClass());
/*     */   }
/*     */ 
/*     */   public String toJson(Object src, Type typeOfSrc)
/*     */   {
/* 519 */     StringWriter writer = new StringWriter();
/* 520 */     toJson(src, typeOfSrc, writer);
/* 521 */     return writer.toString();
/*     */   }
/*     */ 
/*     */   public void toJson(Object src, Appendable writer)
/*     */     throws JsonIOException
/*     */   {
/* 539 */     if (src != null)
/* 540 */       toJson(src, src.getClass(), writer);
/*     */     else
/* 542 */       toJson(JsonNull.INSTANCE, writer);
/*     */   }
/*     */ 
/*     */   public void toJson(Object src, Type typeOfSrc, Appendable writer)
/*     */     throws JsonIOException
/*     */   {
/*     */     try
/*     */     {
/* 564 */       JsonWriter jsonWriter = newJsonWriter(Streams.writerForAppendable(writer));
/* 565 */       toJson(src, typeOfSrc, jsonWriter);
/*     */     } catch (IOException e) {
/* 567 */       throw new JsonIOException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void toJson(Object src, Type typeOfSrc, JsonWriter writer)
/*     */     throws JsonIOException
/*     */   {
/* 578 */     TypeAdapter adapter = getAdapter(TypeToken.get(typeOfSrc));
/* 579 */     boolean oldLenient = writer.isLenient();
/* 580 */     writer.setLenient(true);
/* 581 */     boolean oldHtmlSafe = writer.isHtmlSafe();
/* 582 */     writer.setHtmlSafe(this.htmlSafe);
/* 583 */     boolean oldSerializeNulls = writer.getSerializeNulls();
/* 584 */     writer.setSerializeNulls(this.serializeNulls);
/*     */     try {
/* 586 */       adapter.write(writer, src);
/*     */     } catch (IOException e) {
/* 588 */       throw new JsonIOException(e);
/*     */     } finally {
/* 590 */       writer.setLenient(oldLenient);
/* 591 */       writer.setHtmlSafe(oldHtmlSafe);
/* 592 */       writer.setSerializeNulls(oldSerializeNulls);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toJson(JsonElement jsonElement)
/*     */   {
/* 604 */     StringWriter writer = new StringWriter();
/* 605 */     toJson(jsonElement, writer);
/* 606 */     return writer.toString();
/*     */   }
/*     */ 
/*     */   public void toJson(JsonElement jsonElement, Appendable writer)
/*     */     throws JsonIOException
/*     */   {
/*     */     try
/*     */     {
/* 619 */       JsonWriter jsonWriter = newJsonWriter(Streams.writerForAppendable(writer));
/* 620 */       toJson(jsonElement, jsonWriter);
/*     */     } catch (IOException e) {
/* 622 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private JsonWriter newJsonWriter(Writer writer)
/*     */     throws IOException
/*     */   {
/* 631 */     if (this.generateNonExecutableJson) {
/* 632 */       writer.write(")]}'\n");
/*     */     }
/* 634 */     JsonWriter jsonWriter = new JsonWriter(writer);
/* 635 */     if (this.prettyPrinting) {
/* 636 */       jsonWriter.setIndent("  ");
/*     */     }
/* 638 */     jsonWriter.setSerializeNulls(this.serializeNulls);
/* 639 */     return jsonWriter;
/*     */   }
/*     */ 
/*     */   public void toJson(JsonElement jsonElement, JsonWriter writer)
/*     */     throws JsonIOException
/*     */   {
/* 647 */     boolean oldLenient = writer.isLenient();
/* 648 */     writer.setLenient(true);
/* 649 */     boolean oldHtmlSafe = writer.isHtmlSafe();
/* 650 */     writer.setHtmlSafe(this.htmlSafe);
/* 651 */     boolean oldSerializeNulls = writer.getSerializeNulls();
/* 652 */     writer.setSerializeNulls(this.serializeNulls);
/*     */     try {
/* 654 */       Streams.write(jsonElement, writer);
/*     */     } catch (IOException e) {
/* 656 */       throw new JsonIOException(e);
/*     */     } finally {
/* 658 */       writer.setLenient(oldLenient);
/* 659 */       writer.setHtmlSafe(oldHtmlSafe);
/* 660 */       writer.setSerializeNulls(oldSerializeNulls);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T fromJson(String json, Class<T> classOfT)
/*     */     throws JsonSyntaxException
/*     */   {
/* 682 */     Object object = fromJson(json, classOfT);
/* 683 */     return Primitives.wrap(classOfT).cast(object);
/*     */   }
/*     */ 
/*     */   public <T> T fromJson(String json, Type typeOfT)
/*     */     throws JsonSyntaxException
/*     */   {
/* 706 */     if (json == null) {
/* 707 */       return null;
/*     */     }
/* 709 */     StringReader reader = new StringReader(json);
/* 710 */     Object target = fromJson(reader, typeOfT);
/* 711 */     return target;
/*     */   }
/*     */ 
/*     */   public <T> T fromJson(Reader json, Class<T> classOfT)
/*     */     throws JsonSyntaxException, JsonIOException
/*     */   {
/* 733 */     JsonReader jsonReader = new JsonReader(json);
/* 734 */     Object object = fromJson(jsonReader, classOfT);
/* 735 */     assertFullConsumption(object, jsonReader);
/* 736 */     return Primitives.wrap(classOfT).cast(object);
/*     */   }
/*     */ 
/*     */   public <T> T fromJson(Reader json, Type typeOfT)
/*     */     throws JsonIOException, JsonSyntaxException
/*     */   {
/* 760 */     JsonReader jsonReader = new JsonReader(json);
/* 761 */     Object object = fromJson(jsonReader, typeOfT);
/* 762 */     assertFullConsumption(object, jsonReader);
/* 763 */     return object;
/*     */   }
/*     */ 
/*     */   private static void assertFullConsumption(Object obj, JsonReader reader) {
/*     */     try {
/* 768 */       if ((obj != null) && (reader.peek() != JsonToken.END_DOCUMENT))
/* 769 */         throw new JsonIOException("JSON document was not fully consumed.");
/*     */     }
/*     */     catch (MalformedJsonException e) {
/* 772 */       throw new JsonSyntaxException(e);
/*     */     } catch (IOException e) {
/* 774 */       throw new JsonIOException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T fromJson(JsonReader reader, Type typeOfT)
/*     */     throws JsonIOException, JsonSyntaxException
/*     */   {
/* 788 */     boolean isEmpty = true;
/* 789 */     boolean oldLenient = reader.isLenient();
/* 790 */     reader.setLenient(true);
/*     */     try {
/* 792 */       reader.peek();
/* 793 */       isEmpty = false;
/* 794 */       TypeAdapter typeAdapter = getAdapter(TypeToken.get(typeOfT));
/* 795 */       return typeAdapter.read(reader);
/*     */     }
/*     */     catch (EOFException e)
/*     */     {
/*     */       Object localObject1;
/* 801 */       if (isEmpty) {
/* 802 */         return null;
/*     */       }
/* 804 */       throw new JsonSyntaxException(e);
/*     */     } catch (IllegalStateException e) {
/* 806 */       throw new JsonSyntaxException(e);
/*     */     }
/*     */     catch (IOException e) {
/* 809 */       throw new JsonSyntaxException(e);
/*     */     } finally {
/* 811 */       reader.setLenient(oldLenient);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T fromJson(JsonElement json, Class<T> classOfT)
/*     */     throws JsonSyntaxException
/*     */   {
/* 832 */     Object object = fromJson(json, classOfT);
/* 833 */     return Primitives.wrap(classOfT).cast(object);
/*     */   }
/*     */ 
/*     */   public <T> T fromJson(JsonElement json, Type typeOfT)
/*     */     throws JsonSyntaxException
/*     */   {
/* 856 */     if (json == null) {
/* 857 */       return null;
/*     */     }
/* 859 */     return fromJson(new JsonTreeReader(json), typeOfT);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 889 */     StringBuilder sb = new StringBuilder("{").append("serializeNulls:").append(this.serializeNulls).append("factories:").append(this.factories).append(",instanceCreators:").append(this.constructorConstructor).append("}");
/*     */ 
/* 894 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   static class FutureTypeAdapter<T> extends TypeAdapter<T>
/*     */   {
/*     */     private TypeAdapter<T> delegate;
/*     */ 
/*     */     public void setDelegate(TypeAdapter<T> typeAdapter)
/*     */     {
/* 866 */       if (this.delegate != null) {
/* 867 */         throw new AssertionError();
/*     */       }
/* 869 */       this.delegate = typeAdapter;
/*     */     }
/*     */ 
/*     */     public T read(JsonReader in) throws IOException {
/* 873 */       if (this.delegate == null) {
/* 874 */         throw new IllegalStateException();
/*     */       }
/* 876 */       return this.delegate.read(in);
/*     */     }
/*     */ 
/*     */     public void write(JsonWriter out, T value) throws IOException {
/* 880 */       if (this.delegate == null) {
/* 881 */         throw new IllegalStateException();
/*     */       }
/* 883 */       this.delegate.write(out, value);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/soojin/Downloads/google-gson-2.2.2/gson-2.2.2.jar
 * Qualified Name:     com.google.gson.Gson
 * JD-Core Version:    0.6.2
 */