package org.json.simple;

public abstract interface JSONAware
{
  public abstract String toJSONString();
}