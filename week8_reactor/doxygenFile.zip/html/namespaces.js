var namespaces =
[
    [ "week8_server", "namespaceweek8__server.html", null ]
];