var classweek8__server_1_1_thread_per_dispatcher =
[
    [ "dispatch", "classweek8__server_1_1_thread_per_dispatcher.html#acf253a1552859366b9420eb3ede8ea49", null ]
];