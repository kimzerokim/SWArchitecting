var classweek8__server_1_1_server_initializer =
[
    [ "main", "classweek8__server_1_1_server_initializer.html#a73b9694a5855a87335cbe63c96f8c8a9", null ],
    [ "logger", "classweek8__server_1_1_server_initializer.html#a93ccaaf656ba68e2dd3950bacc0e9b2e", null ]
];