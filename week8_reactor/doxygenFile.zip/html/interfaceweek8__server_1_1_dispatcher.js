var interfaceweek8__server_1_1_dispatcher =
[
    [ "dispatch", "interfaceweek8__server_1_1_dispatcher.html#a29b5387e03751725f89de08211e638b7", null ]
];