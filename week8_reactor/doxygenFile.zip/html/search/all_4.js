var searchData=
[
  ['logger',['logger',['../classweek8__server_1_1_server_initializer.html#a93ccaaf656ba68e2dd3950bacc0e9b2e',1,'week8_server.ServerInitializer.logger()'],['../classweek8__server_1_1_stream_say_hello_event_handler.html#a68c45171ab9184973fa32d5b18f1fc70',1,'week8_server.StreamSayHelloEventHandler.logger()'],['../classweek8__server_1_1_stream_update_profile_event_handler.html#ad704bc0908f0f6b43b7cc21887990f0e',1,'week8_server.StreamUpdateProfileEventHandler.logger()']]]
];
