var searchData=
[
  ['updateprofile',['updateProfile',['../classweek8__server_1_1_stream_update_profile_event_handler.html#ab2a9e69d8c970f9f8ea254337f53f558',1,'week8_server::StreamUpdateProfileEventHandler']]]
];
