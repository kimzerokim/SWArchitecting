var searchData=
[
  ['handlemap',['handleMap',['../classweek8__server_1_1_demultiplexer.html#a9de8a7b062866296383729ba6e4ce0a1',1,'week8_server.Demultiplexer.handleMap()'],['../classweek8__server_1_1_reactor.html#a8ba93454e7dbe329e3fb503b94b5240e',1,'week8_server.Reactor.handleMap()']]],
  ['handler',['handler',['../classweek8__server_1_1_handler_list_data.html#a6905ecd2a867500c1096d5543b36bb91',1,'week8_server::HandlerListData']]],
  ['header_5fsize',['HEADER_SIZE',['../classweek8__server_1_1_demultiplexer.html#a5240d883d891045d3cdf5f5497637eb1',1,'week8_server::Demultiplexer']]]
];
