var searchData=
[
  ['name',['name',['../classweek8__server_1_1_handler_list_data.html#a6b207124eddb629f42eb688e7e107df1',1,'week8_server::HandlerListData']]],
  ['numthreads',['numThreads',['../classweek8__server_1_1_thread_pool_dispatcher.html#af2930528df7e19e996420a857079ea69',1,'week8_server::ThreadPoolDispatcher']]]
];
