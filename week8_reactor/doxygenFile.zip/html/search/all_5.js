var searchData=
[
  ['main',['main',['../classweek8__server_1_1_server_initializer.html#a73b9694a5855a87335cbe63c96f8c8a9',1,'week8_server.ServerInitializer.main()'],['../classweek8__server_1_1_test_client.html#aacba0a9c55b57e6805aee049047f5d99',1,'week8_server.TestClient.main()']]]
];
