var searchData=
[
  ['gethandler',['getHandler',['../interfaceweek8__server_1_1_event_handler.html#a77b9a43471e25538de361dd0fff9478b',1,'week8_server.EventHandler.getHandler()'],['../classweek8__server_1_1_handler_list_data.html#a1f90cf96677728ec88e603b59ae80e8e',1,'week8_server.HandlerListData.getHandler()'],['../classweek8__server_1_1_stream_say_hello_event_handler.html#a179e9b7dae2e32891de7dbc707e3d07e',1,'week8_server.StreamSayHelloEventHandler.getHandler()'],['../classweek8__server_1_1_stream_update_profile_event_handler.html#a0f5b195408dd8fb6b250ce8531a71f02',1,'week8_server.StreamUpdateProfileEventHandler.getHandler()']]],
  ['getname',['getName',['../classweek8__server_1_1_handler_list_data.html#aa7ac90f82d504b25610eb401c729f57d',1,'week8_server::HandlerListData']]],
  ['getserver',['getServer',['../classweek8__server_1_1_server_list_data.html#a290deb1c104276fd65c014e4e4d790f0',1,'week8_server::ServerListData']]]
];
