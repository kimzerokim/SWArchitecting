var searchData=
[
  ['handleevent',['handleEvent',['../interfaceweek8__server_1_1_event_handler.html#a24d2832c020ae27428c12be6d5277e51',1,'week8_server.EventHandler.handleEvent()'],['../classweek8__server_1_1_stream_say_hello_event_handler.html#a2c2be02c3987ca818d6c09fd800d0f34',1,'week8_server.StreamSayHelloEventHandler.handleEvent()'],['../classweek8__server_1_1_stream_update_profile_event_handler.html#a9cf985ef61eff5226bc397d72847abed',1,'week8_server.StreamUpdateProfileEventHandler.handleEvent()']]]
];
