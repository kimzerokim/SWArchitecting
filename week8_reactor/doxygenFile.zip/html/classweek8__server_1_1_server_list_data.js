var classweek8__server_1_1_server_list_data =
[
    [ "getServer", "classweek8__server_1_1_server_list_data.html#a290deb1c104276fd65c014e4e4d790f0", null ],
    [ "server", "classweek8__server_1_1_server_list_data.html#a732d8343a7bb9f2afd473a397a9937aa", null ]
];