var classweek8__server_1_1_handler_list_data =
[
    [ "getHandler", "classweek8__server_1_1_handler_list_data.html#a1f90cf96677728ec88e603b59ae80e8e", null ],
    [ "getName", "classweek8__server_1_1_handler_list_data.html#aa7ac90f82d504b25610eb401c729f57d", null ],
    [ "handler", "classweek8__server_1_1_handler_list_data.html#a6905ecd2a867500c1096d5543b36bb91", null ],
    [ "name", "classweek8__server_1_1_handler_list_data.html#a6b207124eddb629f42eb688e7e107df1", null ]
];