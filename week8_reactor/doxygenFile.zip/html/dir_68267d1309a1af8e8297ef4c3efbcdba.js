var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "week8_server", "dir_7c0036d8e2c0b44779e580aa43594cdd.html", "dir_7c0036d8e2c0b44779e580aa43594cdd" ]
];