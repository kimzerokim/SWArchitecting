var annotated =
[
    [ "week8_server", "namespaceweek8__server.html", "namespaceweek8__server" ]
];