var interfaceweek8__server_1_1_event_handler =
[
    [ "getHandler", "interfaceweek8__server_1_1_event_handler.html#a77b9a43471e25538de361dd0fff9478b", null ],
    [ "handleEvent", "interfaceweek8__server_1_1_event_handler.html#a24d2832c020ae27428c12be6d5277e51", null ]
];